import { render } from 'preact';
import App from './components/App';

let domRoot;

const renderDOM = Component => {
  domRoot = render(<Component />, document.getElementById('root'), domRoot);
};

renderDOM(App);

if (module.hot) {
  module.hot.accept('./components/App', () => renderDOM(App));
}
